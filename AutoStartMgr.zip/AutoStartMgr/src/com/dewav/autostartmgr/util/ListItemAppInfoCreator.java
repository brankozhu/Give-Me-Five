package com.dewav.autostartmgr.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import com.dewav.autostartmgr.R;
import com.dewav.autostartmgr.app.AutoStartApplication;
import com.dewav.autostartmgr.ui.ListItemAppInfo;
import com.dewav.autostartmgr.ui.ListItemAppInfo.AutoStartType;

public class ListItemAppInfoCreator {
	public static AutoStartApplication mApplication = null;
	public Context mContext = null;
	public PackageManager mPackMgr = null;
	public ListItemAppInfoCreator mAppInfoCreator = null;
	
	public ListItemAppInfoCreator(AutoStartApplication app) {
		mApplication = app;
	}
	
	public ListItemAppInfoCreator getSingleInstance() {
		if (mApplication == null) {
			return null;
		}
		
		if (mAppInfoCreator == null) {
			mAppInfoCreator = new ListItemAppInfoCreator(mApplication);
			mPackMgr = mApplication.getPackageManager();
			mContext = mApplication.getAppContext();			
		}
		
		return mAppInfoCreator;
	}
	
	public ListItemAppInfo createListItemAppInfo(ResolveInfo resolveInfo, String action, boolean compState) {
		if (mAppInfoCreator == null) {
			getSingleInstance();
		}
		
		// get package name & component name
		String pkgName = resolveInfo.activityInfo.packageName;
		String compName = resolveInfo.activityInfo.name;
		
		// get label
		CharSequence label = resolveInfo.loadLabel(mPackMgr);
		String apkLabel = label != null ? label.toString() : pkgName;
		
		// get icon
		Drawable icon = resolveInfo.loadIcon(mPackMgr);
		
		// get description & startType
		String descrp = null;
		AutoStartType startType = AutoStartType.AUTO_START_NONE;
		if (action.equals(Intent.ACTION_BOOT_COMPLETED)) {
			descrp = mContext.getString(R.string.boot_start);
			startType = AutoStartType.AUTO_START_BOOT;
		} else {
			descrp = mContext.getString(R.string.background_restart);
			startType = AutoStartType.AUTO_START_BACKGROUND;
		}
		
		// get Button Text
		String btnText = null;
		if (compState) {
			btnText = mContext.getString(R.string.disable);
		} else {
			btnText = mContext.getString(R.string.enable);
		}
		
		// create a new AppInfo.
		ListItemAppInfo appItem = new ListItemAppInfo(icon, pkgName, apkLabel, compName, action, 
												descrp, startType, btnText, compState);
		
		return appItem;
	}
	
	public void updateListItemAppDescrip(ListItemAppInfo appItem, String newAction) {
		AutoStartType startType = AutoStartType.AUTO_START_NONE;
		String updateDesp = null;
		
		if (appItem == null || newAction == null) {
			return;
		}
		
		if (newAction.equals(Intent.ACTION_BOOT_COMPLETED)) {
			startType = AutoStartType.AUTO_START_BOOT;
			updateDesp = mContext.getString(R.string.boot_start);
		} else {
			startType = AutoStartType.AUTO_START_BACKGROUND;
			updateDesp = mContext.getString(R.string.background_restart);
		}
		
		appItem.updateListItemAppDescrip(startType, updateDesp);
	}
	
	public Drawable getAppInfoDrawableIcon(ResolveInfo resolveInfo) {
		return resolveInfo.loadIcon(mPackMgr);
	}

	public String getAppInfoLabel(ResolveInfo resolveInfo) {
        CharSequence label = resolveInfo.loadLabel(mPackMgr);
		return label.toString();
	}
	
	public String getAppInfoBtnText(int resId) {
		return mContext.getString(resId);
	}
	
}
