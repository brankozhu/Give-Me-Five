package com.dewav.autostartmgr.util;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Handler;
import android.util.Log;

import com.dewav.autostartmgr.app.AutoStartApplication;
import com.dewav.autostartmgr.data.AutoStartDBProvider;
import com.dewav.autostartmgr.ui.AutoStartMain;
import com.dewav.autostartmgr.ui.AutoStartRuntimeException;

public class PackMgrCompHelper {
	private static final String TAG = "PackMgrCompHelper";
	public static final int BUTTON_STATE_DISABLE = 0;
	public static final int BUTTON_STATE_ENABLE = 1;
	public static final int BUTTON_STATE_DEFAULT = -1;
	private AutoStartApplication mApplication = null;
	private Context mContext = null;
	private PackageManager mPackMgr = null;
	private Handler mMessagHandler = null;
	private ActivityManager mActivityManger;
	
	public PackMgrCompHelper(AutoStartApplication app) {
		mApplication = app;
		mContext = mApplication.getAppContext();
		mPackMgr = mApplication.getGlobalPackageManager();
		mActivityManger = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
	}
	
	public void setMessageHandler(Handler handler) {
		mMessagHandler = handler;
	}
	
	/*
	 * true: enable component
	 * false: disable component
	 */
	public boolean checkoutComponentEnableSetting(String packageName, String className) {
		int state;
		ComponentName comp = new ComponentName(packageName, className);
		state = mPackMgr.getComponentEnabledSetting(comp);
		if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
				|| state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT) {
			Log.d(TAG, "checkoutComponentEnableSetting: component = " + className + " enable!!!");
			return true;
		} else {
			Log.d(TAG, "checkoutComponentEnableSetting: component = " + className + "  disable!!!");
		}

		return false;
	}
	
	public boolean checkoutComponentEnableSetting(ComponentName compName) {
		int state;
		
		state = mPackMgr.getComponentEnabledSetting(compName);
		if (state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
				|| state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT) {
			Log.d(TAG, "checkoutComponentEnableSetting: component = " + compName.getClassName() + " enable!!!");
			return true;
		} else {
			Log.d(TAG, "checkoutComponentEnableSetting: component = " + compName.getClassName() + "  disable!!!");
		}

		return false;
	}
	
	public boolean runEnableStateSettings(ComponentName CompName, int newState) {
		boolean result = false;
        boolean stateCheck = false;
		Log.d(TAG, "runEnableStateSettings: newState = " + newState);
		
		try {
			if (PackageManager.COMPONENT_ENABLED_STATE_ENABLED == newState) {
				mPackMgr.setComponentEnabledSetting(CompName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
				Log.d(TAG, "set Component Enable: CompName = " + CompName.getClassName());
				
				stateCheck = checkoutComponentEnableSetting(CompName);
                Log.d(TAG, "runEnableStateSettings: stateCheck = " + stateCheck);
				if (stateCheck) {
					result = true;
				}				
			} else if (PackageManager.COMPONENT_ENABLED_STATE_DISABLED == newState) {
				mPackMgr.setComponentEnabledSetting(CompName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
				Log.d(TAG, "set Component Disable: CompName = " + CompName.getClassName());
				
				stateCheck = checkoutComponentEnableSetting(CompName);
                Log.d(TAG, "runEnableStateSettings: stateCheck = " + stateCheck);
				if (stateCheck == false) {
					result = true;
				}
			} else {
				result = false;
			}
		} catch (SecurityException err) {
			result = false;
			Log.e(TAG, "runEnableStateSettings:setComponentEnabledSetting occur Security Exception "  + err);
			throw new RuntimeException();
		} catch(Exception err) {
			Log.e(TAG, "runEnableStateSettings:setComponentEnabledSetting occur Exception " + err);
			throw new RuntimeException();
		}
		
		Log.d(TAG, "runEnableStateSettings result = " + result);
		return result;
	}
	
	public boolean startEnableStateSettings(Cursor cursor, String pkgName, int nextState) throws AutoStartRuntimeException {
		String cmpName;
		int cmpIndex;
		int pkgStateIndex;
		int cmpStateIndex;
		int pkgState = BUTTON_STATE_DEFAULT;
		int cmpState = BUTTON_STATE_DEFAULT;
		int newState = BUTTON_STATE_DEFAULT;
		int failCount = 0;
		boolean finalResult = false;
		
		if (pkgName == null) {
			showWarning(AutoStartMain.MSG_PARAMETER_ERROR);
			return finalResult;
		}
		
		try {
			if (cursor != null) {
				cursor.moveToPosition(-1);
			}
			
			boolean result = false;
			int count = cursor.getCount();
			Log.d(TAG, "startEnableStateSettings : count = " + count);
			
			while(cursor.moveToNext()) {
				// get the component name and component state 
				cmpIndex = cursor.getColumnIndex(AutoStartDBProvider.CMP_NAME);
				pkgStateIndex = cursor.getColumnIndex(AutoStartDBProvider.PKG_STATE);
				cmpStateIndex = cursor.getColumnIndex(AutoStartDBProvider.CMP_STATE);
				cmpName = cursor.getString(cmpIndex);
				pkgState = cursor.getInt(pkgStateIndex);
				cmpState = cursor.getInt(cmpStateIndex);
				
                Log.d(TAG, "startEnableStateSettings: cmpName = " + cmpName + " pkgState = " + pkgState + " cmpState = " + cmpState);
				if ((cmpName == null) || (cmpState == nextState)) {
					Log.d(TAG, "startEnableStateSettings: nextState = " + nextState);
					continue;
				}
				
				ComponentName comp = new ComponentName(pkgName, cmpName);
				if (cmpState == BUTTON_STATE_DISABLE) {
					result = runEnableStateSettings(comp, PackageManager.COMPONENT_ENABLED_STATE_ENABLED);
				} else if (cmpState == BUTTON_STATE_ENABLE) {
					result = runEnableStateSettings(comp, PackageManager.COMPONENT_ENABLED_STATE_DISABLED);
				} else {
					// state error, do nothing!
					Log.d(TAG, "onClick: cmpState error, do nothing!");
					result = false;
				}
				Log.d(TAG, "result = " + result);
				if (result == false) {
                    // execute failed.
					failCount++;
				}				
			}
		} catch(RuntimeException e) {
			Log.d(TAG, "exception = " + e);
			throw new RuntimeException();
		} catch(Exception e) {
			Log.d(TAG, "exception = " + e);
		} finally {	
			if (cursor != null) {
			    cursor.close();
			}
		}
		
		Log.d(TAG, "startEnableStateSettings: fail Count = " + failCount);
		if (failCount > 0) {
			showWarning(AutoStartMain.MSG_EXECUTE_FAIL);
		} else if (failCount == 0) {
			// if disable package success, then stop the package.
			forceStopPackageAsAlreadyStart(pkgName);
			finalResult = true;
		} else {
			Log.d(TAG, "fail count error.");
			showWarning(AutoStartMain.MSG_PARAMETER_ERROR);
		}
		
		return finalResult;
	}
	
	public void forceStopPackageAsAlreadyStart(String pkgName) throws AutoStartRuntimeException {
		try {
//			mActivityManger.forceStopPackage(pkgName);
		} catch(RuntimeException err) {
			Log.d(TAG, "forceStopPackageAsAlreadyStart : RuntimeException =" + err);
			showWarning(AutoStartMain.MSG_STOP_PACKAGE_FAIL);
			throw new AutoStartRuntimeException(err);
		} catch(Exception err) {
			Log.d(TAG, "forceStopPackageAsAlreadyStart : Exception =" + err);
			showWarning(AutoStartMain.MSG_STOP_PACKAGE_FAIL);
			throw new AutoStartRuntimeException(err);
		}
	}
	
    public void showWarning(int what) {
		mMessagHandler.obtainMessage(what).sendToTarget();
	}
}
