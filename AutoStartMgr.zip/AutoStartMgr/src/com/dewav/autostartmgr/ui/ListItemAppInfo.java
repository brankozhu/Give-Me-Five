package com.dewav.autostartmgr.ui;

import android.graphics.drawable.Drawable;
import android.util.Log;

public class ListItemAppInfo {
    private static final String TAG = "ListItemAppInfo";
    public enum AutoStartType {AUTO_START_NONE, AUTO_START_BOOT, AUTO_START_BACKGROUND, AUTO_START_BOTH};
    public enum StateGroup {AUTO_START_ENABLED, AUTO_START_DISABLED};
    
	private Drawable mIcon;
	private String mPackageName;
	private String mLabel;
	private String mComponentName;
	private String mActionName;
	private String mStartDescrip;
	private String mBtnText;
	private AutoStartType mAutoStartType;
	private StateGroup mAutoStartGroup;
	private boolean mbEnabled = false;
	
	public ListItemAppInfo() {
		mAutoStartType = AutoStartType.AUTO_START_NONE;
	}
	
	public ListItemAppInfo(Drawable icon, String pkgName, String label, String compName, String actionName, 
			String descrip, AutoStartType startType, String btnText, boolean compState) {
		mIcon = icon;
		mPackageName = pkgName;
		mLabel = label;
		mComponentName = compName;
		mActionName = actionName;
		mStartDescrip = descrip;		
		mAutoStartType = startType;
		mBtnText = btnText;
		setStateGroup(compState);
	}
	
	public ListItemAppInfo createListItemAppInfo(Drawable icon, String pkgName, String label, String compName, String actionName, 
			String descrip, AutoStartType startType, String btnText, boolean compState) {
		return new ListItemAppInfo(icon, pkgName, label, compName, actionName, 
							descrip, startType, btnText, compState);
	}
	
	public void updateListItemAppDescrip(AutoStartType newType, String updateDesp) {
		if (mAutoStartType == AutoStartType.AUTO_START_BOTH) {
			return;
		}
		
		if (mAutoStartType == newType) {
			return;
		}
		
		if ((mAutoStartType == AutoStartType.AUTO_START_BOOT) 
				&& (newType == AutoStartType.AUTO_START_BACKGROUND)) {
			mAutoStartType = AutoStartType.AUTO_START_BOTH;
			mStartDescrip = mStartDescrip + " " + updateDesp;
		} else if ((mAutoStartType == AutoStartType.AUTO_START_BACKGROUND) 
				&& (newType == AutoStartType.AUTO_START_BOOT)) {
			mAutoStartType = AutoStartType.AUTO_START_BOTH;
			mStartDescrip = updateDesp + " " + mStartDescrip;
		}
	}
	
	public void setStateGroup(boolean state) {
		/*
		 * state: true  belong to enabled group
		 *        false belong to disabled group
		 */
		if (state) {
			mAutoStartGroup = StateGroup.AUTO_START_ENABLED;
			mbEnabled = true;
		} else {
			mAutoStartGroup = StateGroup.AUTO_START_DISABLED;
			mbEnabled = false;
		}
	}
	
	public Drawable getListItemDrawableIcon() {
		return mIcon;
	}
	
	public String getListItemAppPackageName() {
		return mPackageName;
	}
	
	public String getListItemAppLabel() {
		return mLabel;
	}
	
	public String getListItemAppComponentName() {
		return mComponentName;
	}
	
	public String getListItemAppActionName() {
		return mActionName;
	}
	
	public String getListItemAppStartDescription() {
		return mStartDescrip;
	}
	
	public String getListItemButtonText() {
	    return mBtnText;	
	}
	
	public void updateListItemButtonText(String text) {
		mBtnText = text;
	}
	
	public boolean isListItemAppEnabledGroup() {
		Log.d(TAG, "isListItemAppEnabledGroup : mbEnabled = " + mbEnabled);
		return mbEnabled;
	}
	
	public boolean isListemItemAppDisabledGroup() {
		return !mbEnabled;
	}
	
	private StateGroup checkListItemAppStateGroup() {
		return mAutoStartGroup;
	}
	
}
