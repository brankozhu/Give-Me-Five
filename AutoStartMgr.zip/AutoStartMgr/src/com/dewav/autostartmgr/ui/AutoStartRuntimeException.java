package com.dewav.autostartmgr.ui;

public class AutoStartRuntimeException extends Exception {
    public AutoStartRuntimeException(Throwable t) {
        super(t);
    }
}
