package com.dewav.autostartmgr.ui;

import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Calendar;
import com.dewav.autostartmgr.R;
import com.dewav.autostartmgr.app.AutoStartApplication;
import com.dewav.autostartmgr.data.AutoStartDBProvider;
import com.dewav.autostartmgr.util.PackMgrCompHelper;

public class ListViewAdapter extends BaseAdapter {
	private static final String TAG = "ListViewAdapter";
	private static final int KEY_BTN_ATTR = R.id.permit_btn;
	private AutoStartApplication mApplication;
	private Context mContext;
	private LayoutInflater mInflater;
	private List<ListItemAppInfo> mAppInfoList;
	private Handler mMessagHandler;
    private PackMgrCompHelper mPackMgrCompHelper = null;
	
	public ListViewAdapter(AutoStartApplication app, List<ListItemAppInfo> appInfoList, Handler handler) {
		mApplication = app;
		mContext = mApplication.getAppContext();
		mMessagHandler = handler;
        mPackMgrCompHelper = mApplication.getPackMgrComponentHelper();
        mPackMgrCompHelper.setMessageHandler(mMessagHandler);
		mInflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mAppInfoList = appInfoList;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mAppInfoList.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return mAppInfoList.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View layout;
		ListHolder holder;
		
		if (convertView == null || convertView.getTag() == null) {
			layout = mInflater.inflate(R.layout.app_list_item, null);
			holder = new ListHolder(layout);
			layout.setTag(holder);
		} else {
			layout = convertView;
			holder = (ListHolder)layout.getTag();
		}
		
		ListItemAppInfo appItem = (ListItemAppInfo)getItem(position);
		holder.mImage.setImageDrawable(appItem.getListItemDrawableIcon());
		holder.mLabel.setText(appItem.getListItemAppLabel());
		holder.mStartDescrip.setText(appItem.getListItemAppStartDescription());
		holder.mButton.setText(appItem.getListItemButtonText());
		holder.mButton.setTag(KEY_BTN_ATTR, new ButtonClickAttribute(appItem.getListItemAppPackageName(), 
																appItem.isListItemAppEnabledGroup()));
		holder.mButton.setOnClickListener(new NoDoubleClickListener());
		
		return layout;
	}

	public  class NoDoubleClickListener implements OnClickListener {

		public static final int MIN_CLICK_DELAY_TIME = 3000;
		private long lastClickTime = 0;

		@Override
		public void onClick(View v) {
			long currentTime = Calendar.getInstance().getTimeInMillis();
			if (currentTime - lastClickTime > MIN_CLICK_DELAY_TIME) {
				lastClickTime = currentTime;
				clickButton(v);
			}
		}
	}

	public void clickButton(View v) {
		// get package name
		String pkgName;
		boolean curState;
		boolean result = false;
		int nextBtnState = PackMgrCompHelper.BUTTON_STATE_DEFAULT;
		
		Object attr = v.getTag(KEY_BTN_ATTR);
		if (attr instanceof ButtonClickAttribute) {
			pkgName = ((ButtonClickAttribute) attr).getPkgName();
			curState = ((ButtonClickAttribute) attr).getCurState();
			nextBtnState = getNextState(curState);
		} else {
			return;
		}
		
		Log.d(TAG, "clickButton: pkgName = " + pkgName + " curState = " + curState + " nextBtnState = " + nextBtnState);
		
		// get database records
		AutoStartDBProvider dbProvider = mApplication.getAutoStartDBProvider();
		Cursor cursor = dbProvider.queryAllRecordsByPackageName(pkgName);
		
		// disable/enable components by package name
		try {
			result = mPackMgrCompHelper.startEnableStateSettings(cursor, pkgName, nextBtnState);
		} catch (AutoStartRuntimeException err) {
			Log.d(TAG, "AutoStartRuntimeException = " + err);
			showWarning(AutoStartMain.MSG_EXECUTE_FAIL);
		} catch(RuntimeException err) {
			Log.d(TAG, "RuntimeException = " + err);
			showWarning(AutoStartMain.MSG_EXECUTE_FAIL);
		}
		
		Log.d(TAG, "clickButton: result = " + result);
		if (result == false) {
			dbProvider.close();
			return;
		}
		
		// update records and recycle the resources
		dbProvider.updateAllRecordsByPackageName(pkgName, nextBtnState);
		dbProvider.close();
		
		// refresh the listviews
		updateAppListViews(pkgName, nextBtnState);
	}
    
	public void updateAppListViews(String pkgName, int nextState) {
		Bundle bundle = new Bundle();
		bundle.putString("pkgname", pkgName);
		bundle.putInt("newstate", nextState);
		Log.d(TAG, "updateListViews: pkgName = " + pkgName + " nextState = " + nextState);
		
		Message msg = Message.obtain();
		msg.setTarget(mMessagHandler);
		msg.what = AutoStartMain.MSG_UPDATE_LIST;
		msg.setData(bundle);
		msg.sendToTarget();
	}

    public void showWarning(int what) {
		mMessagHandler.obtainMessage(what).sendToTarget();
	}
	
	public int getNextState(boolean curState) {
		if (curState) {
			return PackMgrCompHelper.BUTTON_STATE_DISABLE;
		} else {
			return PackMgrCompHelper.BUTTON_STATE_ENABLE;
		}
	}	

	private class ListHolder {
		ImageView mImage;
		TextView mLabel;
		TextView mStartDescrip;
		Button mButton;
		
		public ListHolder(View layoutView) {
			mImage = (ImageView)layoutView.findViewById(R.id.appicon);
			mLabel = (TextView)layoutView.findViewById(R.id.label_text);
			mStartDescrip = (TextView)layoutView.findViewById(R.id.start_type);
			mButton = (Button)layoutView.findViewById(R.id.permit_btn);
		}
	}
	
	private class ButtonClickAttribute {
		String pkgName;
		boolean curState;
		
		public ButtonClickAttribute(String pkg, boolean state) {
			pkgName = pkg;
			curState = state;
		}
		
		public String getPkgName() {
			return pkgName;
		}
		
		public void setPkgName(String name) {
			pkgName = name;
		}
		
		public boolean getCurState() {
			return curState;
		}
		
		public void setCurState(boolean state) {
			curState = state;
		}
	}	
}
