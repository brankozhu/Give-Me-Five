package com.dewav.autostartmgr.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.dewav.autostartmgr.R;
import com.dewav.autostartmgr.app.AutoStartApplication;
import com.dewav.autostartmgr.data.AutoStartDBProvider;
import com.dewav.autostartmgr.data.ConstActions;
import com.dewav.autostartmgr.util.ListItemAppInfoCreator;
import com.dewav.autostartmgr.util.PackMgrCompHelper;

public class AutoStartMain extends Activity {
    private static final String TAG = "AutoStartMain";
    public enum Filter {FILTER_ALL_APP, FILTER_SYSTEM_APP, FILTER_USER_APP};
	public static final int MSG_UPDATE_LIST = 1;
    public static final int MSG_EXECUTE_FAIL = 2;
    public static final int MSG_PARAMETER_ERROR = 3;
    public static final int MSG_STOP_PACKAGE_FAIL = 4;
    private Context mContext = null;    
    private AutoStartApplication mApplication = null;
    private PackMgrCompHelper mPackMgrCompHelper = null;
    private AutoStartDBProvider mDataBaseProvider = null;
    private ListItemAppInfoCreator mAppInfoCreator = null;
    private Filter mAppListFilter = Filter.FILTER_USER_APP;

	private ListView mEnableAppListView;
	private ListView mDisableAppListView;	
	private ListViewAdapter mEnableAppListAdapter = null;
	private ListViewAdapter mDisableAppListAdapter = null;    
	private ListViewRelayout mListViewRelayout;
	
    private Map<String, ListItemAppInfo> mListItemData;
	private List<ListItemAppInfo> mEnableAppInfoList = null;
	private List<ListItemAppInfo> mDisableAppInfoList = null;
	
	private FrameLayout mEnableTitle;
	private FrameLayout mDisableTitle;
	private TextView mEnableTitleText;
	private TextView mDisableTitleText;
	private ProgressBar mProgressView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.app_list_main);
		
		initializeData();
		initializeViews();
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		setupAppListViews();
	}
	
	public void initializeData() {
		mContext = getApplicationContext();
		mApplication = (AutoStartApplication)getApplication();
		mPackMgrCompHelper = mApplication.getPackMgrComponentHelper();
		mDataBaseProvider = mApplication.getAutoStartDBProvider();
		mAppInfoCreator = mApplication.getAutoStartAppInfoCreator();
		mListItemData = new HashMap<String, ListItemAppInfo>();
		mListViewRelayout = new ListViewRelayout();
	}
	
	public void initializeViews() {
		mProgressView = (ProgressBar) findViewById(R.id.progress_bar);
        mProgressView.setVisibility(View.VISIBLE);
        mProgressView.setIndeterminate(true);
		
		mEnableTitle = (FrameLayout)findViewById(R.id.sub_enable_title);
		mEnableTitle.setVisibility(View.GONE);
		mEnableTitleText = (TextView)findViewById(R.id.enable_title_text);
		
		mDisableTitle = (FrameLayout)findViewById(R.id.sub_disable_title);
		mDisableTitle.setVisibility(View.GONE);
		mDisableTitleText = (TextView)findViewById(R.id.disable_title_text);
		
		mEnableAppListView = (ListView)findViewById(R.id.enable_app_list);
		mDisableAppListView = (ListView)findViewById(R.id.disable_app_list);		
	}

	public void setupAppListViews() {
		new AsyncTask<Void, Void, Void>() {

			@Override
			protected Void doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				queryListViewDataByFilter(mAppListFilter);
				return null;
			}

			@Override
			protected void onPostExecute(Void result) {
				// TODO Auto-generated method stub
				showTitleBar(mEnableAppInfoList.size(), mDisableAppInfoList.size());
				showEnabledAppList();
				showDisabledAppList();
				
				mProgressView.setIndeterminate(false);
		        mProgressView.setVisibility(View.GONE);
			}
			
		}.execute();
	}
	
	public void queryListViewDataByFilter(Filter filter) {
		PackageManager pm = mApplication.getGlobalPackageManager(); 
		if (pm == null) {
			return ;
		}
		
		// create a list to store all app infos.
		createAppInfoList();
		
		String[] actions = ConstActions.getActions();
		for (String action: actions) {
			Intent intent = new Intent(action, null);
			List<ResolveInfo> resolveInfoList = pm.queryBroadcastReceivers(intent, 
																	PackageManager.GET_DISABLED_COMPONENTS);
			
			if (resolveInfoList.size() == 0) {
				continue;
			}
			
			Collections.sort(resolveInfoList, new ResolveInfo.DisplayNameComparator(pm));

			switch (mAppListFilter) {
			case FILTER_USER_APP:
				for (ResolveInfo resolveInfo: resolveInfoList) {
			        ComponentInfo ci = resolveInfo.activityInfo != null ? resolveInfo.activityInfo : resolveInfo.serviceInfo;
			        ApplicationInfo appInfo = ci.applicationInfo;
			        Log.d(TAG, "packageName = " + resolveInfo.activityInfo.packageName);
			        
					if (isUserApp(appInfo.flags)) {
						boolean compState = mPackMgrCompHelper.checkoutComponentEnableSetting(resolveInfo.activityInfo.packageName, 
																						resolveInfo.activityInfo.name);
						// set up database, for record will be used in disable component.
						mDataBaseProvider.setupDatabaseRecord(resolveInfo, action, compState);
						
						// set display list filter by package name, and fill up the auto start description.
						setupListItemFilterByName(resolveInfo, action, compState);
					}
				}
				
				break;
			case FILTER_ALL_APP:
				break;
			case FILTER_SYSTEM_APP:
				break;
			}
		}
		
		Set<String> keys = mListItemData.keySet();
		for (String key : keys) {
			ListItemAppInfo appInfo = mListItemData.get(key);
			
			Log.d(TAG, "queryListViewDataByFilter : key = " + key);
			if (appInfo.isListItemAppEnabledGroup()) {
				mEnableAppInfoList.add(appInfo);
			} else {
				mDisableAppInfoList.add(appInfo);
			}
		}		
	}
	
	public void createAppInfoList() {
		if (mEnableAppInfoList == null) {
			mEnableAppInfoList = new ArrayList<ListItemAppInfo>();
		}
		
		if (mDisableAppInfoList == null) {
			mDisableAppInfoList = new ArrayList<ListItemAppInfo>();
		}
		
		mEnableAppInfoList.clear();
		mDisableAppInfoList.clear();
	}
	
	boolean isUserApp(int flag) {
		boolean bUserApp = false;
		
		if ((flag & ApplicationInfo.FLAG_SYSTEM) <= 0) {
			bUserApp = true;
		} else if ((flag & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
			bUserApp = true;
		}
		
		return bUserApp;
	}
	
	boolean isSystemApp(int flag) {
		boolean bSystemApp = false;
		
		if ((flag & ApplicationInfo.FLAG_SYSTEM) != 0) {
			bSystemApp = true;
		}
		return bSystemApp;
	}	
	
	public void showTitleBar(int enableAppSize, int disableAppSize) {
		mEnableTitle.setVisibility(View.VISIBLE);
		mEnableTitleText.setText(getString(R.string.enable_apps) + "(" + enableAppSize + ")");
		
		mDisableTitle.setVisibility(View.VISIBLE);
		mDisableTitleText.setText(getString(R.string.disable_apps) + "(" + disableAppSize + ")");
	}
	
	public void showEnabledAppList() {
		mEnableAppListAdapter = new ListViewAdapter(mApplication, mEnableAppInfoList, mMessagHandler);
		mEnableAppListView.setAdapter(mEnableAppListAdapter);
		mListViewRelayout.setListViewHeightBasedOnChildren(mEnableAppListView);	
	}
	
	public void showDisabledAppList() {	
		mDisableAppListAdapter = new ListViewAdapter(mApplication, mDisableAppInfoList, mMessagHandler);
		mDisableAppListView.setAdapter(mDisableAppListAdapter);
		mListViewRelayout.setListViewHeightBasedOnChildren(mDisableAppListView);		
	}
	
	ListItemAppInfo setupListItemFilterByName(ResolveInfo resolveInfo, String action, boolean compState) {
		ListItemAppInfo appItem = null;
		String pkgName = resolveInfo.activityInfo.packageName;
		
		// check the package name in display records.
		appItem = mListItemData.get(pkgName);
		if (appItem == null) {
			// have not this record now
			appItem = mAppInfoCreator.createListItemAppInfo(resolveInfo, action, compState);
			mListItemData.put(pkgName, appItem);
			return appItem;
		} else {
			// already have this record, the component may be different, so judge the action.
			if (action.equals(appItem.getListItemAppActionName())) {
				return null;
			} else {
				mAppInfoCreator.updateListItemAppDescrip(appItem, action);
			}
		}
		
		return appItem;
	}
	
    public void updateListViews(Message msg) {
		Bundle bundle = msg.getData();
		// get the list item info
		String pkgName = bundle.getString("pkgname");
		int nextState = bundle.getInt("newstate");
		
		// update the enable ListView and disable ListView
		ListItemAppInfo appItem = mListItemData.get(pkgName);
		Log.d(TAG, "updateListViews: pkgName = " + pkgName + " nextState = " + nextState);
		Log.d(TAG, "updateListViews: appItem = " + appItem);
		if (nextState == PackMgrCompHelper.BUTTON_STATE_ENABLE) {
			appItem.setStateGroup(true);
			appItem.updateListItemButtonText(getString(R.string.disable));			
			mDisableAppInfoList.remove(appItem);
			mEnableAppInfoList.add(appItem);
		} else {
			appItem.setStateGroup(false);
			appItem.updateListItemButtonText(getString(R.string.enable));			
			mEnableAppInfoList.remove(appItem);
			mDisableAppInfoList.add(appItem);
		}
		
		showTitleBar(mEnableAppInfoList.size(), mDisableAppInfoList.size());
		mEnableAppListAdapter.notifyDataSetChanged();
		mListViewRelayout.setListViewHeightBasedOnChildren(mEnableAppListView);
		
		mDisableAppListAdapter.notifyDataSetChanged();
		mListViewRelayout.setListViewHeightBasedOnChildren(mDisableAppListView);
    }	
	
	private Handler mMessagHandler = new Handler() {  
		  
	    @Override  
	    public void handleMessage(Message msg) {
	    	
	        // TODO Auto-generated method stub  
	    	switch (msg.what) {
	    	case MSG_UPDATE_LIST:
    	    	{
		    		Log.d(TAG, "handleMessage: update ListViews");
		    		updateListViews(msg);
    	    	}
	    		break;
	    	case MSG_EXECUTE_FAIL:
	    	    {
	    		    Log.d(TAG, "handleMessage: Execute failed, Please try again!");
	    		    Toast.makeText(mContext, getString(R.string.execute_fail), 1000).show();
	    	    }
                break;
	    	case MSG_PARAMETER_ERROR:
	    	    {
	    		    Log.d(TAG, "handleMessage: Parameter error!");
	    		    Toast.makeText(mContext, getString(R.string.parameter_error), 1000).show();
	    	    }
	            break;
	    	case MSG_STOP_PACKAGE_FAIL:
	    	    {
	    		    Log.d(TAG, "handleMessage: Force stop package failed!");
	    		    Toast.makeText(mContext, getString(R.string.stop_package_fail), 1000).show();
	    	    }
	            break;
	    	default:
	    		break;
	    	}
	    }  
	          
	};	
}
