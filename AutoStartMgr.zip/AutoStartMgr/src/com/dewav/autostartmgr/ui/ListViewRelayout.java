package com.dewav.autostartmgr.ui;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;

public class ListViewRelayout {
	public void setListViewHeightBasedOnChildren(ListView listView) {
		// get ListView's Adapter
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		
		int totalHeight = 0;
		// get the ListView count
		int count = listAdapter.getCount();
		for (int i = 0; i < count; i++) {
			View listItem = listAdapter.getView(i, null, listView);
			// measure the child view
			listItem.measure(0, 0);
			// calculate the total height of items
			totalHeight += listItem.getMeasuredHeight();
		}
		
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		// get divider height for all items and add the total height
		params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		listView.setLayoutParams(params);
    }

}
