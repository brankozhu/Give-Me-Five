package com.dewav.autostartmgr.app;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.util.Log;

import com.dewav.autostartmgr.data.ConstActions;
import com.dewav.autostartmgr.ui.ListItemAppInfo;
import com.dewav.autostartmgr.util.PackMgrCompHelper;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
public class MyReceiver extends BroadcastReceiver {
    static final String BOOTACTION = "android.intent.action.BOOT_COMPLETED";
    private PackageManager mPackMgr = null;
    private AutoStartApplication mApplication = null;
    private List<ListItemAppInfo> mEnableAppInfoList = null;
    private List<ListItemAppInfo> mDisableAppInfoList = null;
    private PackMgrCompHelper mPackMgrCompHelper = null;
    public enum Filter {FILTER_ALL_APP, FILTER_SYSTEM_APP, FILTER_USER_APP};
    private Filter mAppListFilter = Filter.FILTER_USER_APP;
    private Context mContext;
    SharedPreferences sharedPreferences;

    public MyReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        if (BOOTACTION.equals(intent.getAction())) {
            Log.i("zhuya","yes,i have received"+intent.getAction());
            Context mContext = context;
            sharedPreferences = mContext.getSharedPreferences("share", 1);
            boolean isFirstRun = sharedPreferences.getBoolean("isFirstRun", true);
            Editor editor = sharedPreferences.edit();
            if (isFirstRun) {
                Log.i("zhuya","this is my first"+isFirstRun);
                editor.putBoolean("isFirstRun", false);
                editor.commit();
                closeAppAutoStart(mContext);
            } else {
                Log.i("dfdf", "dfasfsdfsdfdsf");
            }
        }else if(intent.getAction().equals("android.intent.action.PACKAGE_ADDED")){
            String packageName=intent.getDataString().substring(8);
            Context mContext = context;
            closeAppAutoStart(mContext,packageName);                               
                           
        }
    }

    //this for fisrt time open
    public void closeAppAutoStart(Context mContext){
        mPackMgr = mContext.getPackageManager();
        mApplication = (AutoStartApplication) mContext.getApplicationContext();
        mPackMgrCompHelper = mApplication.getPackMgrComponentHelper();        
        PackageManager pm = mApplication.getPackageManager();
        if (pm == null) {
            return ;
        }
        createAppInfoList();
        String[] actions = ConstActions.getActions();
        for (String action: actions) {
            Intent intent1 = new Intent(action, null);
            List<ResolveInfo> resolveInfoList = pm.queryBroadcastReceivers(intent1,
                    PackageManager.GET_DISABLED_COMPONENTS);
            if (resolveInfoList.size() == 0) {
                continue;
            }
            Collections.sort(resolveInfoList, new ResolveInfo.DisplayNameComparator(pm));
            switch (mAppListFilter) {
                case FILTER_USER_APP:
                    for (ResolveInfo resolveInfo : resolveInfoList) {
                        ComponentInfo ci = resolveInfo.activityInfo != null ? resolveInfo.activityInfo : resolveInfo.serviceInfo;
                        ApplicationInfo appInfo = ci.applicationInfo;                       
                        if (isUserApp(appInfo.flags)) {                                                     
                            String pkgName = resolveInfo.activityInfo.packageName;
                            String cmpName = resolveInfo.activityInfo.name;
                            ComponentName comp = new ComponentName(pkgName, cmpName);
                            String[] whitePkgName = ConstActions.getWhiteListpkgname();
                            Boolean isContain=Arrays.asList(whitePkgName).contains(pkgName);
                            if (!isContain) {
                             mPackMgr.setComponentEnabledSetting(comp, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
                            }else{
                              mPackMgr.setComponentEnabledSetting(comp, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
                            }                            
                        }
                    }
                    break;
                case FILTER_ALL_APP:
                    break;
                case FILTER_SYSTEM_APP:
                    break;
            }
        }
    }


   //this method for add apk 
   public void closeAppAutoStart(Context mContext,String packageName){
        mPackMgr = mContext.getPackageManager();
        mApplication = (AutoStartApplication) mContext.getApplicationContext();
        mPackMgrCompHelper = mApplication.getPackMgrComponentHelper();        
        PackageManager pm = mApplication.getPackageManager();
        if (pm == null) {
            return ;
        }
        createAppInfoList();
        String[] actions = ConstActions.getActions();
        for (String action: actions) {
            Intent intent1 = new Intent(action, null);
            List<ResolveInfo> resolveInfoList = pm.queryBroadcastReceivers(intent1,
                    PackageManager.GET_DISABLED_COMPONENTS);
            if (resolveInfoList.size() == 0) {
                continue;
            }
            Collections.sort(resolveInfoList, new ResolveInfo.DisplayNameComparator(pm));           
                    for (ResolveInfo resolveInfo : resolveInfoList) {
                        ComponentInfo ci = resolveInfo.activityInfo != null ? resolveInfo.activityInfo : resolveInfo.serviceInfo;
                        ApplicationInfo appInfo = ci.applicationInfo;                        
                        if (isUserApp(appInfo.flags)) {                                                      
                            String pkgName = resolveInfo.activityInfo.packageName;
                            String cmpName = resolveInfo.activityInfo.name;
                            ComponentName comp = new ComponentName(pkgName, cmpName);
                            String[] whitePkgName = ConstActions.getWhiteListpkgname();
                            Boolean isContain=Arrays.asList(whitePkgName).contains(pkgName);
                            if (!isContain && packageName.equals(pkgName)) {                                
                                mPackMgr.setComponentEnabledSetting(comp, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);                               
                            }
                            }                            
                        }
                    }          
}
    


    public void createAppInfoList() {
        if (mEnableAppInfoList == null) {
            mEnableAppInfoList = new ArrayList<ListItemAppInfo>();
        }

        if (mDisableAppInfoList == null) {
            mDisableAppInfoList = new ArrayList<ListItemAppInfo>();
        }

        mEnableAppInfoList.clear();
        mDisableAppInfoList.clear();
    }

    boolean isUserApp(int flag) {
        boolean bUserApp = false;

        if ((flag & ApplicationInfo.FLAG_SYSTEM) <= 0) {
            bUserApp = true;
        } else if ((flag & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
            bUserApp = true;
        }

        return bUserApp;
    }

}
