package com.dewav.autostartmgr.app;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;

import com.dewav.autostartmgr.data.AutoStartDBProvider;
import com.dewav.autostartmgr.util.ListItemAppInfoCreator;
import com.dewav.autostartmgr.util.PackMgrCompHelper;

public class AutoStartApplication extends Application {
    private static final String TAG = "AutoStartApplication";
	private Context mContext;
	private AutoStartApplication mApplication = null;
	private PackageManager mPackMgr = null;
	private PackMgrCompHelper mPackMgrCompHelper = null;
	private AutoStartDBProvider mDataBaseProvider = null;
	private ListItemAppInfoCreator mAppInfoCreator = null;
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Log.d(TAG, "AutoStartApplication: onCreate");
		
		mContext = getApplicationContext();
		mApplication = this;
		mPackMgr = getPackageManager();
		mPackMgrCompHelper = new PackMgrCompHelper(this);
		mDataBaseProvider = getAutoStartDBProvider();
		mAppInfoCreator = new ListItemAppInfoCreator(this);
	}

	public AutoStartApplication getApplication() {
		return mApplication;
	}
	
	public Context getAppContext() {
		return mContext;
	}
	
	public PackageManager getGlobalPackageManager() {
		return mPackMgr;
	}
	
	public PackMgrCompHelper getPackMgrComponentHelper() {
		return mPackMgrCompHelper;
	}
	
	public synchronized AutoStartDBProvider getAutoStartDBProvider() {
		return mDataBaseProvider.getInstance(mContext);
	}
	
    public ListItemAppInfoCreator getAutoStartAppInfoCreator() {
    	return mAppInfoCreator;
    }
}
