package com.dewav.autostartmgr.data;

import android.accounts.AccountManager;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.media.audiofx.AudioEffect;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;

public class ConstActions {
	private static final String[] AUTO_START_ACTIONS = {
		Intent.ACTION_BOOT_COMPLETED,
		Intent.ACTION_CONFIGURATION_CHANGED,
		Intent.ACTION_MEDIA_CHECKING,
		Intent.ACTION_MEDIA_MOUNTED,
		Intent.ACTION_MEDIA_SCANNER_FINISHED,
		Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
		Intent.ACTION_MEDIA_UNMOUNTED,
		Intent.ACTION_MEDIA_EJECT,
		Intent.ACTION_MEDIA_NOFS,
		Intent.ACTION_NEW_OUTGOING_CALL,
		Intent.ACTION_SCREEN_OFF,
		Intent.ACTION_SCREEN_ON,
		Intent.ACTION_DATE_CHANGED,
		Intent.ACTION_TIME_CHANGED,
		Intent.ACTION_TIME_TICK,
		Intent.ACTION_TIMEZONE_CHANGED,
		Intent.ACTION_PACKAGE_ADDED,
		Intent.ACTION_PACKAGE_CHANGED,
		Intent.ACTION_PACKAGE_DATA_CLEARED,
		Intent.ACTION_PACKAGE_REMOVED,
		Intent.ACTION_PACKAGE_REPLACED,
		Intent.ACTION_POWER_CONNECTED,
		Intent.ACTION_POWER_DISCONNECTED,
		Intent.ACTION_PROVIDER_CHANGED,
		Intent.ACTION_CALL,
		Intent.ACTION_DIAL,
		Intent.ACTION_WEB_SEARCH,
		Intent.ACTION_USER_PRESENT,
		AppWidgetManager.ACTION_APPWIDGET_ENABLED,
		AppWidgetManager.ACTION_APPWIDGET_UPDATE,
		AppWidgetManager.ACTION_APPWIDGET_DISABLED,
		ConnectivityManager.CONNECTIVITY_ACTION,
		ConnectivityManager.ACTION_BACKGROUND_DATA_SETTING_CHANGED,
		WifiManager.WIFI_STATE_CHANGED_ACTION,
		AccountManager.LOGIN_ACCOUNTS_CHANGED_ACTION,
		AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION,
		AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION,
		
	};
	
	public static String[] getActions() {
		return AUTO_START_ACTIONS;
	}

        private static final String[] WHITE_LISTPKGNAME={
			"com.tencent.mm",
			"com.tencent.mobileqq",
			"com.facebook.katana",
	};
	public static String[] getWhiteListpkgname() {
		return WHITE_LISTPKGNAME;
	}
}
