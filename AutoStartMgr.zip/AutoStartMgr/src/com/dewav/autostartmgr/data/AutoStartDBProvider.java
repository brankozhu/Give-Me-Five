package com.dewav.autostartmgr.data;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class AutoStartDBProvider extends SQLiteOpenHelper {
	private static final String TAG = "AutoStartDBProvider";
	
	private static final String DATABASE_NAME = "autostartapp.db";
	private static final String TABLE_APPS_NAME = "app_table";
	public static final String APPS_ID = "_id";
	public static final String PKG_NAME = "_pkgName";
	public static final String CMP_NAME = "_cmpName";
	public static final String ACTION = "_actionName";
	public static final String PKG_STATE = "_pkgState";
	public static final String CMP_STATE = "_cmpState";
	private static final int DATABASE_VERSION = 1;
	private static AutoStartDBProvider mDBProvider = null;
	
	public AutoStartDBProvider(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	public static AutoStartDBProvider getInstance(Context context) {
		Log.d(TAG, "getInstance() : mDBProvider = " + mDBProvider);
		if (mDBProvider == null) {
			mDBProvider = new AutoStartDBProvider(context);
		}
		
		return mDBProvider;
	}	
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		Log.d(TAG, "Create Database TABLE: " + TABLE_APPS_NAME);
		String createSql = "CREATE TABLE " + TABLE_APPS_NAME + " ( " + 
							APPS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
							PKG_NAME + " TEXT NOT NULL, " +
							CMP_NAME + " TEXT NOT NULL, " + 
							ACTION + " TEXT NOT NULL, " + 
							PKG_STATE + " BOOLEAN, " +
							CMP_STATE + " BOOLEAN, " + 
							"CONSTRAINT pkg_comp UNIQUE (" + PKG_NAME + "," + CMP_NAME + ")" +
							" ) ";
		db.execSQL(createSql);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub

	}
	
	public void setupDatabaseRecord(ResolveInfo resolveInfo, String action, boolean compState) {
		String pkgName = resolveInfo.activityInfo.packageName;
		String cmpName = resolveInfo.activityInfo.name;
		
		// Insert a record to the database.
		SQLiteDatabase db = getWritableDatabase();
		if(queryIsOrNotHave(pkgName,cmpName)) {
			// compState equal to pkgState temporary
			insert(db, pkgName, cmpName, action, compState, compState);
		}		
	}
	
	public void insert(SQLiteDatabase db, ContentValues values) {
		try {
			db.insert(TABLE_APPS_NAME, null, values);
		} catch(SQLiteConstraintException e) {
			Log.d(TAG, "Insert a record has the same component name!");
		} catch(Exception e) {
			Log.d(TAG, "exception: e = " + e);
		}
	}
	
	public void insert(SQLiteDatabase db, String pkgName, String cmpName, 
			String action, boolean pkgState, boolean cmpState) {
		/*
		 * insert into app_table (_pkgName, _cmpName, _actionName, _pkgState, _cmpState) 
		 * values 
		 * ("com.example.bootcompletetestapp", "com.example.bootcompletetestapp.MediaMountedReceiver", 
		 * "android.intent.action.MEDIA_MOUNTED", 1, 1)
		 * */ 
		ContentValues values = new ContentValues();
		values.put(PKG_NAME, pkgName);
		values.put(CMP_NAME, cmpName);
		values.put(ACTION, action);
		values.put(PKG_STATE, pkgState);
		values.put(CMP_STATE, cmpState);
		
		insert(db, values);
	}	

	public Cursor query(String querySql, String[] args) {
		SQLiteDatabase db = getReadableDatabase();
		Cursor cursor = db.rawQuery(querySql, args);
		return cursor;
	}
	

        public Boolean queryIsOrNotHave(String pkgName,String compName){
		SQLiteDatabase db = getReadableDatabase();
		String querySql = "select " + PKG_NAME + " , " + CMP_STATE + " from " + TABLE_APPS_NAME + " where " +
				CMP_NAME + " = '" + compName + "'" + " and " + PKG_NAME + " = '" + pkgName + "'";
		Cursor cursorIsOrNot = db.rawQuery(querySql, null);
		if (cursorIsOrNot.moveToFirst() == false){
                        cursorIsOrNot.close();
			return true;
		}else {
                        cursorIsOrNot.close();
			return false;
		}
	}


	public Cursor queryByComponentName(String compName) {
		SQLiteDatabase db = getReadableDatabase();
		String querySql = "select " + PKG_NAME + " , " + CMP_STATE + " from " + TABLE_APPS_NAME + " where " + 
						CMP_NAME + " = '" + compName + "'";
		
		Cursor cursor = db.rawQuery(querySql, null);
		return cursor;
	}
	
	public Cursor queryAllRecordsByPackageName(String pkgName) {
		SQLiteDatabase db = getReadableDatabase();
		String querySql = "select DISTINCT " + CMP_NAME + " , " + PKG_STATE + " , " + CMP_STATE + " from " + TABLE_APPS_NAME +
				" where " + PKG_NAME + " = '" + pkgName + "'";

		Cursor cursor = db.rawQuery(querySql, null);
		return cursor;		
	}
	
	public void updateAllRecordsByPackageName(String pkgName, int newState) {
		updatePkgAndCompStateByPkgName(pkgName, newState);
	}
	
	public void updateCompStateByCompName(String compName, int newState) {
		// update app_table set _cmpState = 0 where _cmpName = 'com.example.bootcompletetestapp.BootupReceiver'
		String updateSql = "update " + TABLE_APPS_NAME + " set " + CMP_STATE + " = " + newState + 
				" where " + CMP_NAME + " = '" + compName + "'";
		
		SQLiteDatabase db = getWritableDatabase();
		
		Log.d(TAG, "updateRecordByCompName: compName = " + compName);
		Log.d(TAG, "updateRecordByCompName: newState = " + newState);
		
		db.execSQL(updateSql);
	}
	
	public void updatePkgAndCompStateByPkgName(String pkgName, int newState) {
		// update app_table set _pkgState = 1, _cmpState = 1 where _pkgName = 'com.example.bootcompletetestapp'
		String updateSql = "update " + TABLE_APPS_NAME + " set " + PKG_STATE + " = " + newState + " , " +
						CMP_STATE + " = " + newState + " where " + PKG_NAME + " = '" + pkgName + "'";
		
		SQLiteDatabase db = getWritableDatabase();
		
		Log.d(TAG, "updateRecordByCompName: pkgName = " + pkgName);
		Log.d(TAG, "updateRecordByCompName: newState = " + newState);
		
		db.execSQL(updateSql);
	}
	
}
